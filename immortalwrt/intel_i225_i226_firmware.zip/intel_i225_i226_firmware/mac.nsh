@echo -off
cls
echo "                                                                       "
echo "  Execute the following command specifying your system's MAC address   "
echo "                                                                       "
echo "            eeupdate64e.efi  /nic=1  /mac=xxxxxxxxxxxx                 "
echo "          where xxxxxxxxxxxx is your system's MAC address              "
echo "                                                                       "

:END