@echo -off

echo Please wait while the necessary files are copied...
cp eeupdate64e.efi FXVL_15F3_V_1MB_1.89.eep \

@echo -off
echo ************************************************

eeupdate64e.efi /device=15F3

if %lasterror% == 0 then

   goto V
else

   goto LM


endif




:V
eeupdate64e.efi /device=15F3 /nic=1 /data=FXVL_15F3_V_1MB_1.89.eep /verify=FXVL_15F3_V_1MB_1.89.eep /test


if not %lasterror% == 0 then

   goto EEUPERR

endif

goto end



:LM
eeupdate64e.efi /device=15F2 /nic=1 /data=FXVL_15F2_LM_1MB_1.89.eep /verify=FXVL_15F2_LM_1MB_1.89.eep /test

if not %lasterror% == 0 then

   goto EEUPERR

endif


goto end



:EEUPERR
cls
echo ***********************************
echo "* An EEUPDATE failure occured. *"
echo ***********************************

:END
