@echo off
cls
echo Pre-install tool EEUPDATEW64e.exe:
call install.bat 

echo Check EEPROM Image information:
EEUPDATEW64e.exe /nic=1 /eepromver >temp.txt

findstr /C:"1.89" temp.txt >nul
if %errorlevel% equ 0 (
echo NVM version is the latest, no need to upgrade
del /f "temp.txt"
call uninstall.bat
goto :END
)

findstr /C:"8086-15F2" temp.txt >nul
if %errorlevel% equ 0 (
echo LAN is vPro SKU
EEUPDATEW64e.exe /nic=1 /d NVM\FXVL_15F2_LM_1MB_1.89.bin
) else (
echo LAN is Non-vPro SKU
EEUPDATEW64e.exe /nic=1 /d NVM\FXVL_15F3_V_1MB_1.89.bin
)

del /f "temp.txt"
call uninstall.bat

echo The Computer will shut down to take effect after pressing any key, then you can press power button to turn on it, thanks!
Pause
shutdown.exe -s

:END





